// ===== 설정 =====
const API_BASE = 'https://nohu-lab.vercel.app/api/admin'
const SYNC_SECRET = 'nohu-cafe-sync-2026'
const CAFE_ID = '20898041'
const VERIFY_POLL_INTERVAL = 3000
// =================

function waitForTabLoad(tabId) {
  return new Promise(resolve => {
    chrome.tabs.onUpdated.addListener(function listener(id, info) {
      if (id === tabId && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener)
        resolve()
      }
    })
  })
}

async function runInTab(tabId, func, args) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId }, func, args: args || [], world: 'MAIN',
    })
    return results[0]?.result
  } catch (e) {
    console.log(`[verify] runInTab 에러: ${e.message}`)
    return null
  }
}

async function tabExists(tabId) {
  try { await chrome.tabs.get(tabId); return true } catch { return false }
}

// ── 카페 관리 탭 ──
let cafeTabId = null

async function ensureCafeTab() {
  if (cafeTabId && await tabExists(cafeTabId)) {
    return cafeTabId
  }

  const tabs = await chrome.tabs.query({ url: 'https://cafe.naver.com/ManageWholeMember*' })
  if (tabs.length > 0) {
    cafeTabId = tabs[0].id
    console.log(`[verify] 기존 카페 관리 탭 사용: ${cafeTabId}`)
    return cafeTabId
  }

  console.log('[verify] 카페 관리 페이지 새로 열기...')
  const tab = await chrome.tabs.create({
    url: `https://cafe.naver.com/ManageWholeMember.nhn?clubid=${CAFE_ID}`,
    active: false,
  })
  cafeTabId = tab.id
  await waitForTabLoad(tab.id)
  console.log('[verify] 페이지 로드 완료, 8초 대기...')
  await new Promise(r => setTimeout(r, 8000))
  return cafeTabId
}

// ── 단일 닉네임 검색 ──
async function searchNicknameInCafe(nickname) {
  const tabId = await ensureCafeTab()
  console.log(`[verify] 탭 ${tabId}에서 "${nickname}" 검색 시작`)

  // Step 1: 검색 키워드 설정 + requestMemberList 호출
  const setupResult = await runInTab(tabId, (searchNick) => {
    try {
      if (typeof nhn === 'undefined' || !nhn.cafemanage || !nhn.cafemanage.member) {
        return { error: 'nhn.cafemanage.member 객체 없음' }
      }

      const member = nhn.cafemanage.member
      member._htParameter['search.keyword'] = searchNick
      member._htParameter['search.page'] = 1

      // 현재 DOM의 회원 수 기록 (변경 감지용)
      const beforeCount = document.querySelectorAll('tr[memberid]').length
      window.__verifyBefore = beforeCount

      // 요청 발사
      member.requestMemberList()
      return { started: true, beforeCount }
    } catch(e) {
      return { error: e.message }
    }
  }, [nickname])

  console.log(`[verify] setup 결과:`, JSON.stringify(setupResult))

  if (!setupResult || setupResult.error) {
    console.log(`[verify] 검색 실패: ${setupResult?.error}`)
    cafeTabId = null
    return null
  }

  // Step 2: DOM 변경 대기 후 파싱 (최대 10초)
  // requestMemberList가 완료되면 DOM이 자동으로 업데이트됨
  await new Promise(r => setTimeout(r, 3000)) // 최소 3초 대기

  for (let i = 0; i < 14; i++) {
    if (!(await tabExists(tabId))) {
      console.log('[verify] 탭이 닫힘')
      cafeTabId = null
      return null
    }

    const dom = await runInTab(tabId, () => {
      const members = []
      for (const row of document.querySelectorAll('tr[memberid]')) {
        const nickEl = row.querySelector('a.nick, a[class*="nick"], a[onclick*="NicknameUI"]')
        if (!nickEl) continue
        const nick = nickEl.textContent.trim()
        if (!nick || nick.length > 50) continue
        let grade = ''
        for (const td of row.querySelectorAll('td')) {
          const t = td.textContent.trim()
          if (['일반회원','코어회원','우수회원','프리미엄회원','시그니처회원','헤리티지회원','매니저','스탭','운영진'].includes(t)) {
            grade = t; break
          }
        }
        members.push({ nickname: nick, gradeName: grade || '일반회원' })
      }
      // 페이지 내 검색 키워드 확인
      const searchInput = document.querySelector('input[name="search.keyword"], input.keyword, #search-keyword')
      const currentKeyword = searchInput ? searchInput.value : 'N/A'
      return { members, count: members.length, keyword: currentKeyword }
    })

    console.log(`[verify] DOM 확인 (${i}): ${dom?.count}명, keyword="${dom?.keyword}"`)

    if (dom && dom.count !== undefined) {
      // DOM에 결과가 있으면 (검색 결과가 달라졌거나 3초 이상 지남)
      if (i >= 0) { // 첫 번째 체크부터 결과 사용
        console.log(`[verify] 검색 완료: ${dom.count}명`)
        // 키워드 초기화
        await runInTab(tabId, () => {
          if (nhn?.cafemanage?.member?._htParameter) {
            nhn.cafemanage.member._htParameter['search.keyword'] = ''
          }
        })
        return dom.members || []
      }
    }

    await new Promise(r => setTimeout(r, 500))
  }

  console.log('[verify] 검색 타임아웃')
  return null
}

// ── 확인 요청 폴링 ──
let isVerifying = false

async function pollVerifyRequests() {
  if (isVerifying) return
  isVerifying = true

  try {
    const res = await fetch(`${API_BASE}/verify-poll`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ secret: SYNC_SECRET }),
    })
    if (!res.ok) {
      console.log(`[verify] 폴링 HTTP ${res.status}`)
      return
    }

    const { requests } = await res.json()
    if (!requests || requests.length === 0) return

    for (const req of requests) {
      console.log(`[verify] 회원 확인 요청: "${req.nickname}" (id: ${req.id})`)

      try {
        const members = await searchNicknameInCafe(req.nickname)

        if (members === null) {
          console.log(`[verify] "${req.nickname}" 검색 실패 → error 보고`)
          await fetch(`${API_BASE}/verify-result`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ secret: SYNC_SECRET, id: req.id, status: 'error' }),
          })
          continue
        }

        // 정확히 일치하는 닉네임 찾기
        const found = members.find(m =>
          m.nickname.trim() === req.nickname.trim() ||
          m.nickname.replace(/\s*\([^)]+\)\s*$/, '').trim() === req.nickname.trim()
        )

        if (found) {
          console.log(`[verify] 찾음! "${found.nickname}" (${found.gradeName})`)
          await fetch(`${API_BASE}/verify-result`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              secret: SYNC_SECRET,
              id: req.id,
              status: 'found',
              gradeName: found.gradeName,
            }),
          })
        } else {
          console.log(`[verify] 못찾음: "${req.nickname}" (검색결과: ${members.map(m=>m.nickname).join(', ')})`)
          await fetch(`${API_BASE}/verify-result`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ secret: SYNC_SECRET, id: req.id, status: 'not_found' }),
          })
        }
      } catch(e) {
        console.error(`[verify] 처리 오류:`, e)
        await fetch(`${API_BASE}/verify-result`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ secret: SYNC_SECRET, id: req.id, status: 'error' }),
        })
      }
    }
  } catch(e) {
    console.log(`[verify] 폴링 오류: ${e.message}`)
  } finally {
    isVerifying = false
  }
}

async function saveStatus(status) {
  await chrome.storage.local.set({ syncStatus: status })
}

// ── 3초마다 폴링 ──
setInterval(pollVerifyRequests, VERIFY_POLL_INTERVAL)

// ── 이벤트 ──
chrome.runtime.onInstalled.addListener(() => {
  console.log('[cafe-sync] 확장프로그램 설치됨 - 실시간 회원 확인 모드')
  saveStatus({ success: true, log: ['실시간 확인 모드 실행 중'], lastSync: new Date().toISOString() })
})

chrome.runtime.onStartup.addListener(() => console.log('[cafe-sync] 시작'))

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'sync-now') {
    pollVerifyRequests().then(() => sendResponse({ done: true }))
    return true
  }
  if (msg.action === 'get-status') {
    chrome.storage.local.get('syncStatus', d => sendResponse(d.syncStatus || null))
    return true
  }
})
