function updateUI(status) {
  const box = document.getElementById('statusBox')
  const info = document.getElementById('infoBox')
  const logBox = document.getElementById('logBox')

  if (!status) {
    box.className = 'status loading'
    box.textContent = '확장프로그램 시작 대기 중...'
    info.innerHTML = '브라우저를 재시작하거나 잠시 기다려주세요.'
    return
  }

  if (status.success) {
    box.className = 'status ok'
    box.textContent = '✓ 실행 중'
    info.innerHTML = '<strong>3초마다 로그인 요청을 확인하고 있습니다.</strong>'
  } else {
    box.className = 'status fail'
    box.textContent = '✗ 오류'
  }

  if (status.lastSync) {
    const time = new Date(status.lastSync).toLocaleString('ko-KR')
    info.innerHTML += `<div class="time">마지막 상태: ${time}</div>`
  }

  if (status.log && status.log.length > 0) {
    logBox.style.display = 'block'
    logBox.innerHTML = status.log.map(l => `<div>${l}</div>`).join('')
  }
}

// 초기 상태 로드
chrome.runtime.sendMessage({ action: 'get-status' }, (status) => {
  updateUI(status)
})
